# WER
## Word Embedding Research (version 0.1)
